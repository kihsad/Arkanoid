﻿using Arkanoid;

namespace Assets.Scripts
{
    public interface IBallCollisionHandler
    {

        void Handle(BallMover ball);
       
    }
}
