﻿using UnityEngine;

namespace Arkanoid
{
    public class Player1 : MonoBehaviour
    {
        private static Player1 _instance;
        public static Player1 Instance => _instance;
        private void Awake()
        {
            if (_instance != null)
            {
                Destroy(gameObject);
            }
            else
            {
                _instance = this;
            }
        }
    }
}