﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using static UnityEngine.InputSystem.InputAction;

namespace Arkanoid
{
    [RequireComponent(typeof(Rigidbody))]
    public class PlayerController : MonoBehaviour
    {
        [SerializeField] private InputAction _moveInputAction;
        [SerializeField] private InputAction _launchInputAction;
        [SerializeField, Range(0, 10)] private float _movementSpeed;
        private BallManager _ball;
        private Rigidbody _rigidbody;

        private void Awake()
        {
            
            _ball = FindObjectOfType<BallManager>();
        }

        private void Update()
        {
           
            OnMovement();
        }


        private void OnMovement()
        {
            var direction = _moveInputAction.ReadValue<Vector2>();
            var velocity = new Vector3(direction.x, 0f, direction.y);
            transform.position += velocity * _movementSpeed * Time.deltaTime;
        }

        private void OnDestroy()
        {
            _moveInputAction.Dispose();
        }

        private void OnEnable()
        {
            _moveInputAction.Enable();
            _launchInputAction.Enable();
            _launchInputAction.performed += Launching;
        }

        private void OnDisable()
        {
            _moveInputAction.Disable();
            _launchInputAction.Disable();
            _launchInputAction.performed -= Launching;
        }
        
        public void Launching(InputAction.CallbackContext context)
        {
            _ball.initialBallRB.AddForce(new Vector3(0f, 0.2f, 0f));
            GameManager.Instance.IsGameOn = true;
            Debug.Log("Ball is launched");
        }
    }
}