﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.InputSystem.InputAction;

namespace Arkanoid
{
    public class BallManager : MonoBehaviour
    {
        [SerializeField]
        private Ball ballPrefab;
        private Ball initialBall;
        public Rigidbody initialBallRB;
        [SerializeField, Range(0, 10)] public float _ballSpeed;
        Vector3 _lastVelocity;
        public List<Ball> Balls { get; set; }
        private static BallManager _instance;
        public static BallManager Instance => _instance;
        

        public void Awake()
        {
            if (_instance != null)
            {
                Destroy(gameObject);
            }
            else
            {
                _instance = this;
            }
            
        }

        public void Start()
        {
            InstantiateBall();
            
        }
       
        private void InstantiateBall()
        {
            Vector3 playerPosition = Player1.Instance.gameObject.transform.position;
            Vector3 startingPosition = new Vector3(playerPosition.x, playerPosition.y-2f, playerPosition.z);
            initialBall = Instantiate(ballPrefab, startingPosition, Quaternion.identity);
            initialBallRB = initialBall.GetComponent<Rigidbody>();
            this.Balls = new List<Ball>
            {
                initialBall
            };
            Debug.Log("Ball is created");

        }


       public  void Update()
        {
            _lastVelocity = initialBallRB.velocity;
            if (!GameManager.Instance.IsGameOn)
            {
                Vector3 playerPosition = Player1.Instance.gameObject.transform.position;
                Vector3 ballPosition = new Vector3(playerPosition.x, playerPosition.y-2f, playerPosition.z);
                initialBall.transform.position = ballPosition;
            }
            else
            {
                initialBallRB.AddForce(new Vector3(0f, 1f, 0f));
            }

        }
      
    }
}