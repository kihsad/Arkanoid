﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace Arkanoid 
{
    public class BlocksController : MonoBehaviour
    {
        [SerializeField] public Object _sphericalBlock;
    }

}


