﻿using UnityEngine;

namespace Arkanoid
{
    public class Ball : MonoBehaviour
    {

        private Rigidbody rb;
        public void Start()
        {
            rb = GetComponent<Rigidbody>();
            rb.AddForce(new Vector3(0f, 0.2f, 0f));
            Debug.Log("Ball is on");
        }

    }
}