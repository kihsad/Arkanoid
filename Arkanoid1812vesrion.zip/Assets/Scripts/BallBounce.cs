﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Arkanoid
{
    public class BallBounce : MonoBehaviour
    {
        private Rigidbody rb;
        Vector3 lastVelocity;
        private void Awake()
        {
            rb = GetComponent<Rigidbody>();
        }

        void Update()
        {
            lastVelocity = rb.velocity;
        }

      

        private void OnCollisionEnter(Collision coll)//colliding method
        {

            if (coll.collider.TryGetComponent (out Player2 player2))//colliding with player platforms
            {
               
                Debug.Log("Ball is collided with player2");

                var speed = lastVelocity.magnitude;
                var direction = Vector3.Reflect(lastVelocity.normalized, coll.contacts[0].normal);

                rb.velocity = direction * Mathf.Max(speed, 0.5f);
            }


            if (coll.collider.TryGetComponent(out Player1 player1))//colliding with player platforms
            {

                Debug.Log("Ball is collided with player1");

                var speed = lastVelocity.magnitude;
                var direction = Vector3.Reflect(lastVelocity.normalized, coll.contacts[0].normal);

                rb.velocity = direction * Mathf.Max(speed, 0.5f);
            }

            if (coll.collider.TryGetComponent(out BlocksController blocksController))//colliding with sphere blocks and destroying it giving score to player
            {
                Debug.Log("Ball is collided with block");

                Destroy(blocksController.gameObject);//destroying sphere

                var speed = lastVelocity.magnitude;
                var direction = Vector3.Reflect(lastVelocity.normalized, coll.contacts[0].normal);

                rb.velocity = direction * Mathf.Max(speed, 0.5f);
            }

            if (coll.collider.TryGetComponent(out TubeController tubeController))//colliding with walls
            {
                Debug.Log("Ball is collided with tube walls");

                var speed = lastVelocity.magnitude;
                var direction = Vector3.Reflect(lastVelocity.normalized, coll.contacts[0].normal);

                rb.velocity = direction * Mathf.Max(speed, 0.5f);
            }


            if (coll.collider.TryGetComponent(out LimitController limitController))//colliding with limit walls
            {
                Debug.Log("Ball is out the game");

                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

               
            }

        }

       
    }
}